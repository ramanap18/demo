package com.demo.runnerpackage;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
	@CucumberOptions(
	features = "C:\\Users\\DELL\\eclipse-workspace\\Payment\\Automation\\Feature\\login.feature",
	glue = "com.demo.stepdefination",
			plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
			monochrome = true,
			publish = true)
	public class Runner {
		
	}

