package com.demo.stepdefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.demo.browsers.Brower;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Stpedefination {
	
	public WebDriver driver1;
	public Stpedefination() {
		
		Brower sbc1= Brower.getInstanceOfSingletonBrowserClass();
		driver1 = sbc1.getDriver();
		
	}
	
	@Given("user able to launch application")
	public void user_able_to_launch_application() {
			driver1.get("https://www.amazon.in/");
	}

	@When("user can able enter username {string}")
	public void user_can_able_enter_username(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("userame is  "+string);
	}
	@When("user can able enter passowrd {string}")
	public void user_can_able_enter_passowrd(String string) {

		System.out.println("password is   "+string);
	}

	@Then("user can able to click on login button")
	public void user_can_able_to_click_on_login_button() {
		 System.out.println("password");
		 driver1.close();
	}
}
