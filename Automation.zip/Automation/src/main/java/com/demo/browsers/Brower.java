package com.demo.browsers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Brower {

	private static Brower instanceOfSingletonBrowserClass=null;
	private WebDriver driver;
	
	
	  // Constructor
	private Brower() {
		// TODO Auto-generated constructor stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\eclipse-workspace\\Payment\\Automation\\drivers\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	 
    
    // TO create instance of class
    public void Brower getInstanceOfSingletonBrowserClass(){
        if(instanceOfSingletonBrowserClass==null){
        	instanceOfSingletonBrowserClass = new Brower();
        }
        return instanceOfSingletonBrowserClass;
    }
    
    // To get driver
    public WebDriver getDriver()
    {
    	return driver;
    }
    

   
}